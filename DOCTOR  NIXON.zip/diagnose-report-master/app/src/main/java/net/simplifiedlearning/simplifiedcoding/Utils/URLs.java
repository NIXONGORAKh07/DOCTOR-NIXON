package net.simplifiedlearning.simplifiedcoding.Utils;

/**
 * Created by Belal on 9/5/2017.
 */

public class URLs {

    private static final String ROOT_URL = "http://10.0.2.2/diagnose-report/";

    public static final String URL_REGISTER = ROOT_URL + "api.php?apicall=signup";
    public static final String URL_LOGIN = ROOT_URL + "api.php?apicall=login";
    public static final String URL_UPLOAD = ROOT_URL + "reports.php/";

}
